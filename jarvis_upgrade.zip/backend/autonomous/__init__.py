"""
Autonomous agent package.
"""
